package statistic.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import statistic.model.PlayerInGame;
import statistic.service.PlayerInGameService;
import statistic.service.PlayerService;
import statistic.support.PlayerInGameDTOToPlayerInGame;
import statistic.support.PlayerInGameToDTO;
import statistic.web.dto.PlayerInGameDTO;

@RestController
@RequestMapping("/api/playersInGame")
public class PlayerInGameController {

	@Autowired
	private PlayerInGameService inGameS;
	@Autowired
	private PlayerInGameToDTO toDTO;
	@Autowired
	private PlayerInGameDTOToPlayerInGame toInGame;
	@Autowired
	private PlayerService plS;

	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<PlayerInGameDTO>> get() {
		System.out.println("usao uu metodu========================================");
		return new ResponseEntity<>(toDTO.convert(inGameS.findAll()), HttpStatus.OK);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<PlayerInGameDTO> get(@PathVariable Long id) {

		PlayerInGame p = inGameS.findOne(id);

		if (p == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<PlayerInGameDTO> add(@Validated @RequestBody PlayerInGameDTO newInGame) {

		PlayerInGame p = toInGame.convert(newInGame);
		inGameS.save(p);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.CREATED);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}")
	public ResponseEntity<PlayerInGameDTO> edit(@PathVariable Long id,
			@Validated @RequestBody PlayerInGameDTO izmenjen) {

		if (!id.equals(izmenjen.getId())) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		PlayerInGame p = toInGame.convert(izmenjen);
		inGameS.save(p);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/{id}")
	public ResponseEntity<PlayerInGameDTO> delete(@PathVariable Long id) {
		inGameS.remove(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/onePointShot")
	public ResponseEntity<PlayerInGameDTO> oneShot(@PathVariable Long id) {
		System.out.println(id);
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addOneShot(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/onePointScore")
	public ResponseEntity<PlayerInGameDTO> oneScore(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addOneShot(id);
		inGameS.addOneScore(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/twoPointShot")
	public ResponseEntity<PlayerInGameDTO> twoShot(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addTwoShot(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/twoPointScore")
	public ResponseEntity<PlayerInGameDTO> twoScore(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addTwoShot(id);
		inGameS.addTwoScore(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/threePointShot")
	public ResponseEntity<PlayerInGameDTO> threeShot(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addThreeShot(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/threePointScore")
	public ResponseEntity<PlayerInGameDTO> threeScore(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addThreeShot(id);
		inGameS.addThreeScore(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/assist")
	public ResponseEntity<PlayerInGameDTO> assist(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addAssist(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/faul")
	public ResponseEntity<PlayerInGameDTO> faul(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addFaul(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/to")
	public ResponseEntity<PlayerInGameDTO> to(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addTO(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/def")
	public ResponseEntity<PlayerInGameDTO> defReb(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addDefRebound(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/off")
	public ResponseEntity<PlayerInGameDTO> offReb(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addOffRebound(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/steal")
	public ResponseEntity<PlayerInGameDTO> steal(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addSteal(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}/block")
	public ResponseEntity<PlayerInGameDTO> block(@PathVariable Long id) {
		PlayerInGame p = inGameS.findOne(id);
		if (p == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		inGameS.addBlock(id);

		return new ResponseEntity<>(toDTO.convert(p), HttpStatus.OK);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/{id}/byTeamId")
	public ResponseEntity<List<PlayerInGameDTO>> getPlayersInGame(@PathVariable Long id, @RequestParam Long gameId) {
		List<PlayerInGame> ret = inGameS.findPlayers(id, gameId);
		if (ret == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		System.out.println(ret.size());

		return new ResponseEntity<>(toDTO.convert(ret), HttpStatus.OK);
	}

}
