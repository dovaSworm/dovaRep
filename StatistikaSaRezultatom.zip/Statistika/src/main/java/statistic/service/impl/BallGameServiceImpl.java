package statistic.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import statistic.model.BallGame;
import statistic.model.Player;
import statistic.model.PlayerInGame;
import statistic.model.Team;
import statistic.repository.BallGameRepository;
import statistic.repository.PlayerInGameRepository;
import statistic.repository.TeamRepositiry;
import statistic.service.BallGameService;
import statistic.service.PlayerInGameService;
import statistic.service.PlayerService;

@Service
@Transactional
public class BallGameServiceImpl implements BallGameService {

	@Autowired
	private BallGameRepository bgr;
	@Autowired
	private TeamRepositiry tr;
	@Autowired
	private PlayerInGameRepository inGameR;
	@Autowired
	private PlayerInGameService inGameService;
	@Autowired
	private PlayerService playerS;

	@Override
	public BallGame save(BallGame bg) {
		// TODO Auto-generated method stub
//		addPlayersToList(bg);
		return bgr.save(bg);
	}

	@Override
	public BallGame findOne(Long id) {
		// TODO Auto-generated method stub
		return bgr.findOne(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		bgr.delete(id);
	}

	@Override
	public BallGame result(Long id) {

		BallGame bg = bgr.findOne(id);
		
//		addPlayersToList(bg);
		
		int hostPoints = bg.getHostPlayers().stream().mapToInt(PlayerInGame::getTotalPoints).sum();
		int guestPoints = bg.getGuestPlayers().stream().mapToInt(PlayerInGame::getTotalPoints).sum();

		bg.setGuestPoints(guestPoints);
		bg.setHostPoints(hostPoints);
		
		return bg;

	}

	@Override
	public BallGame timeOut(Long gameId, Long teamId) {

		BallGame bg = bgr.findOne(gameId);
		Team t = tr.findOne(teamId);
		if (t.equals(bg.getGuest())) {
			bg.setGuestTimeOut(bg.getGuestTimeOut() - 1);
		} else {
			bg.setGuestTimeOut(bg.getHostTimeOut() - 1);
		}
		return bg;
	}

	@Override
	public List<BallGame> findAll() {
		// TODO Auto-generated method stub
		return bgr.findAll();
	}
//	@Override
//	public void addPlayersToList(BallGame bg) {
//		if(bg.getHostPlayers().isEmpty()) {
//			List<PlayerInGame> hosts = playerS.findByTeamId(bg.getHost().getId());//new ArrayList<>();
//			for(PlayerInGame p : hosts) {
//				bg.addHostPlayerInGame(p);
//				}
//			bgr.save(bg);
//			}
//		
//		if(bg.getGuestPlayers().isEmpty()) {
//			List<PlayerInGame> guest = playerS.findByTeamId(bg.getGuest().getId());//new ArrayList<>();
//			for(PlayerInGame p : guest) {
//				bg.addGuestPlayerInGame(p);
//				}
//			bgr.save(bg);
//			}
//	}


}
