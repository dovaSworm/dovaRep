package statistic.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import statistic.model.BallGame;
import statistic.model.Player;
import statistic.model.PlayerInGame;
import statistic.repository.BallGameRepository;
import statistic.repository.PlayerInGameRepository;
import statistic.repository.PlayerRepository;
import statistic.service.PlayerInGameService;
import statistic.service.PlayerService;
@Service
@Transactional
public class PlayerInGameServiceImpl implements PlayerInGameService{

	@Autowired
	private PlayerRepository plR;
	@Autowired
	private BallGameRepository bgR;
	@Autowired
	private PlayerInGameRepository inGameR;
	@Autowired
	private PlayerService plS;
	@Override
	public void save(PlayerInGame p) {
		// TODO Auto-generated method stub
		inGameR.save(p);
	}

	@Override
	public void remove(Long id) {
		// TODO Auto-generated method stub
		inGameR.delete(id);
	}

	@Override
	public PlayerInGame findOne(long id) {
		// TODO Auto-generated method stub
		return inGameR.findOne(id);
	}

	@Override
	public List<PlayerInGame> findAll() {
		// TODO Auto-generated method stub
		return inGameR.findAll();
	}

	@Override
	public void addOneShot(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setOnePointShot((p.getOnePointShot() + 1));
		inGameR.save(p);
	}

	@Override
	public void addOneScore(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setOnePointScore((p.getOnePointScore()+1));
		p.setTotalPoints(p.getTotalPoints() + 1);
		inGameR.save(p);
	}

	@Override
	public void addTwoShot(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setTwoPointShot((p.getTwoPointShot() + 1));
		inGameR.save(p);
		
	}

	@Override
	public void addTwoScore(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setTwoPointScore((p.getTwoPointScore() + 1));
		p.setTotalPoints(p.getTotalPoints() + 2);
		inGameR.save(p);
		
	}

	@Override
	public void addThreeShot(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setThreePointShot((p.getThreePointShot() + 1));
		inGameR.save(p);
		
	}

	@Override
	public void addThreeScore(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setThreePointScore((p.getThreePointScore() + 1));
		p.setTotalPoints(p.getTotalPoints() + 3);
		inGameR.save(p);
		
	}

	@Override
	public void addSteal(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setSteal((p.getSteal() + 1));
		inGameR.save(p);
		
	}

	@Override
	public void addTO(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setTurnOver((p.getTurnOver() + 1));
		inGameR.save(p);
		
	}

	@Override
	public void addBlock(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setBlockShot((p.getBlockShot() + 1));
		inGameR.save(p);
		
	}

	
	@Override
	public void addOffRebound(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setReboundOff((p.getReboundOff() + 1));
		p.setTotalRebounds(p.getTotalRebounds() + 1);
		inGameR.save(p);
		
	}

	@Override
	public void addDefRebound(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setReboundDef((p.getReboundDef() + 1));
		p.setTotalRebounds(p.getTotalRebounds() + 1);
		inGameR.save(p);
		
	}

	@Override
	public void addAssist(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setAssist((p.getAssist() + 1));
		inGameR.save(p);
		
	}

	@Override
	public void addFaul(Long id) {
		PlayerInGame p = inGameR.findOne(id);
		p.setPersonalFaul((short) (p.getPersonalFaul() + 1));
		if(p.getPersonalFaul() == 5) {
			p.setFouledOut(true);
		}
		inGameR.save(p);
		
	}

	@Override
	public List<PlayerInGame> findByGameId(Long gameId) {
		// TODO Auto-generated method stub
		return inGameR.findByGameId(gameId);
	}

	@Override
	public List<PlayerInGame> findPlayers(Long id, Long gameId) {
		// TODO Auto-generated method stub
		List<PlayerInGame> players; 
		players = inGameR.findByGameId(gameId);
		if(players.isEmpty()) {
			List<Player> regularPlayers = plR.findByTeamId(id);
			BallGame bg = bgR.findOne(gameId);
			for(Player p : regularPlayers) {
				players = new ArrayList<>();
				PlayerInGame playerInGame = new PlayerInGame(p);
				playerInGame.setGame(bg);
				inGameR.save(playerInGame);
				players.add(playerInGame);
			}
		}
		List<PlayerInGame> ret = new ArrayList<>();
		for(PlayerInGame p : players) {
			if(p.getPlayer().getTeam().getId() == id) {
				ret.add(p);
			}
		}
		List<PlayerInGame> reteeee = players.stream().filter(player -> id.equals(player.getPlayer().getTeam().getId())).collect(Collectors.toList());
		return reteeee;
	}
}
