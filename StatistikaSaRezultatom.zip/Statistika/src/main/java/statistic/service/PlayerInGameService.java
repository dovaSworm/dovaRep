package statistic.service;

import java.util.List;


import statistic.model.PlayerInGame;

public interface PlayerInGameService {
	
	void save(PlayerInGame p);
	void remove(Long id);
	PlayerInGame findOne(long id);
	List<PlayerInGame> findAll();
	
	void addOneShot(Long id);
	void addOneScore(Long id);
	void addTwoShot(Long id);
	void addTwoScore(Long id);
	void addThreeShot(Long id);
	void addThreeScore(Long id);
	void addSteal(Long id);
	void addTO(Long id);
	void addBlock(Long id);
	void addOffRebound(Long id);
	void addDefRebound(Long id);
	void addAssist(Long id);
	void addFaul(Long id);
	
	List<PlayerInGame> findByGameId(Long id);
	List<PlayerInGame> findPlayers(Long id, Long gameId);

}
