package statistic.service;

import java.util.List;

import org.springframework.data.domain.Page;

import statistic.model.BallGame;
import statistic.model.Player;
import statistic.model.PlayerInGame;
import statistic.web.dto.PlayerInGameDTO;

public interface PlayerService {

	boolean save(Player p);
	void remove(Long id);
	Player findOne(long id);
	Page<Player> findAll(int pageNum);
//	List<PlayerInGame> findByTeamId(Long teamId);
	List<PlayerInGame> findPlayers(Long id, Long gameId);
}
