package statistic;

import java.util.ArrayList;

import statistic.model.Player;

public class Test {

	public static void main(String[] args) {}
//		Player p1 = new Player();
//		Player p2 = new Player();
//		Player p3 = new Player();
//		 p1.setTotalPoints(2);
//		p2.setTotalPoints(2);
//		p3.setTotalPoints(2);
//		
//		ArrayList<Player> hostPlayers = new ArrayList<>(); //(ArrayList<Player>) pr.findByTeamId(host.getId());
//		
//		hostPlayers.add(p3);
//		hostPlayers.add(p2);
//		hostPlayers.add(p1);
////		ArrayList<Player> guestPlayers = (ArrayList<Player>) pr.findByTeamId(guest.getId());
//			
//		int hostPoints = hostPlayers.stream().mapToInt(Player::getTotalPoints).sum();
//		System.out.println(hostPoints);
////		int guestPoints = guestPlayers.stream().mapToInt(Player::getTotalPoints).sum();
//
//	}

}
