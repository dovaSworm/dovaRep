var statisticApp = angular.module("statisticApp", [ 'ngRoute' ]);

statisticApp.config([ '$routeProvider', function($routeProvider) {
	$routeProvider.when('/', {
		templateUrl : '/app/html/statistic.html'
	}).when('/edit', {
		templateUrl : '/app/html/edit-players.html'
	}).otherwise({
		redirectTo : '/'
	});
} ]);



statisticApp.controller("playersCtrl", function($scope, $http, $location) {

	var baseUrlPlayers = "/api/players";
	var baseUrlTeams = "/api/teams";
	var baseUrlPositions = "/api/positions";

	$scope.pageNum = 0;
	$scope.totalPages = 0;

	$scope.teamA = [];
	$scope.teamB = [];
	$scope.teams = [];
	$scope.teamAid;
	$scope.teamBid;

	var getHostPlayers = function() {
		$http.get(baseUrlTeams + "/" + $scope.teamAid + "/players").then(
				function(res) {
					$scope.teamA = res.data;
					console.log($scope.teamA);
				}, function(res) {
					alert("wrong");
				})
	}
	
	var getGuestPlayers = function() {
		$http.get(baseUrlTeams + "/" + $scope.teamBid + "/players").then(
				function(res) {
					$scope.teamB = res.data;
					console.log($scope.teamB);
				}, function(res) {
					alert("wrong");
				})
	}
	
	$scope.addHost = function() {
		getHostPlayers();
	}

	$scope.addGuest = function() {
		getGuestPlayers();
	}
	
//	 $scope.izmeni = function(id){
//	        $location.path('/players/edit/' + id);
//	    }

	var getTeams = function() {
		$http.get(baseUrlTeams).then(function success(res) {
			$scope.teams = res.data;
		}, function error(res) {
			alert("Unsuccessful!");
		});
	};

	getTeams();

	
});
/////////////////////////dodavanje i editovanje igraca/////////////////////////////////////////////
statisticApp.controller("editAddPlayerCtrl", function($scope, $http,
		$routeParams, $location) {

	var baseUrlPlayers = "/api/players";
	var baseUrlPositions = "/api/positions"
	var baseUrlTeams = "/api/teams"
	
	
	$scope.newPlayer = {};
	$scope.newPlayer.name;
	$scope.newPlayer.jerseyNumber;
	$scope.newPlayer.positionId;
	$scope.newPlayer.teamId;
	$scope.newPlayer.onePointShot = 0;
	$scope.newPlayer.onePointScore = 0;
	$scope.newPlayer.twoPointShot = 0;
	$scope.newPlayer.twoPointScore = 0;
	$scope.newPlayer.threePointShot = 0;
	$scope.newPlayer.threePointScore = 0;
	$scope.newPlayer.assist = 0;
	$scope.newPlayer.steal = 0;
	$scope.newPlayer.turnOver = 0;
	$scope.newPlayer.reboundOff = 0;
	$scope.newPlayer.reboundDef = 0;
	$scope.newPlayer.blockShot = 0;
	$scope.newPlayer.personalFaul = 0;
	$scope.newPlayer.totalPoints = 0;
	$scope.newPlayer.totalRebounds = 0;
	
	$scope.teams = [];
	$scope.positions = [];
	$scope.players = [];
	
	var getTeams = function() {
		$http.get(baseUrlTeams).then(
				function(res) {
					$scope.teams = res.data;
				}, function(res) {
					alert("wrong");
				})
	}
	getTeams();
	
	var getPositions = function() {
		$http.get(baseUrlPositions).then(
				function(res) {
					$scope.positions = res.data;
				}, function(res) {
					alert("wrong");
				})
	}
	getPositions();
	
	var getPlayers = function() {
		$http.get(baseUrlPlayers).then(
				function(res) {
					$scope.players = res.data;
				}, function(res) {
					alert("wrong");
				})
	}
	getPlayers();
	
	$scope.add = function() {
		$http.post(baseUrlPlayers, $scope.newPlayer).then(
				function success(res) {
					getPlayers();
					$scope.newPlayer = {};
					$scope.newPlayer.name;
					$scope.newPlayer.number;
					$scope.newPlayer.positionId;
					$scope.newPlayer.teamId;
					$scope.newPlayer.onePointShoot = 0;
					$scope.newPlayer.onePointScore = 0;
					$scope.newPlayer.twoPointShoot = 0;
					$scope.newPlayer.twoPointScore = 0;
					$scope.newPlayer.threePointShoot = 0;
					$scope.newPlayer.threePointScore = 0;
					$scope.newPlayer.assists = 0;
					$scope.newPlayer.steal = 0;
					$scope.newPlayer.turnOver = 0;
					$scope.newPlayer.offRebound = 0;
					$scope.newPlayer.defRebound = 0;
					$scope.newPlayer.block = 0;
					$scope.newPlayer.faul = 0;
					$scope.newPlayer.poeniTotal = 0;
					$scope.newPlayer.skokTotal = 0;
				}, function error(res) {
					alert("Unsuccessful adding! Team is loaded");
				});
	};
	
	$scope.oldPlayerId;
	$scope.getOldPlayer = function() {
		$http.get(baseUrlPlayers + "/" + $scope.oldPlayerId).then(
				function success(res) {
					$scope.newPlayer = res.data;
					console.log(res.data);
				}, function error(data) {
					alert("Unsuccessful players geting.");
				});

	};
	
	$scope.edit = function() {
		$http.put(baseUrlPlayers + "/protectedByAdminRole/" + $scope.oldPlayerId,
				$scope.newPlayer).then(function success(data) {
			alert("Successfull editing!");
			$location.path("/");
		}, function error(data) {
			alert("Unsuccessful editing.");
		});
	}
});
/////////////////////////////////STATISTIC/////////////////////////////////////////////////////////////////
statisticApp.controller("statisticCtrl", function($scope, $http,
		$routeParams, $location) {

	var baseUrlPlayersInGame = "/api/playersInGame";
	var baseUrlPlayers = "/api/players";
	var baseUrlBallGame = "/api/ballGame"
	var baseUrlTeams = "/api/teams"
	
	$scope.newBallGame = {};
	$scope.newBallGame.hostId;
	$scope.newBallGame.guestId;
	$scope.newBallGame.hostPoints = 0;
	$scope.newBallGame.guestPoints = 0;
	$scope.newBallGame.hostTimeOut = 3;
	$scope.newBallGame.guestTimeOut = 3;
	
	$scope.hostPlayers = [];
	$scope.guestPlayers = [];
	
	$scope.newPlayerInGame = {};
	$scope.newPlayerInGame.name;
	$scope.newPlayerInGame.jerseyNumber;
	$scope.newPlayerInGame.positionId;
	$scope.newPlayerInGame.teamId;
	$scope.newPlayerInGame.onePointShot = 0;
	$scope.newPlayerInGame.onePointScore = 0;
	$scope.newPlayerInGame.twoPointShot = 0;
	$scope.newPlayerInGame.twoPointScore = 0;
	$scope.newPlayerInGame.threePointShot = 0;
	$scope.newPlayerInGame.threePointScore = 0;
	$scope.newPlayerInGame.assist = 0;
	$scope.newPlayerInGame.steal = 0;
	$scope.newPlayerInGame.turnOver = 0;
	$scope.newPlayerInGame.reboundOff = 0;
	$scope.newPlayerInGame.reboundDef = 0;
	$scope.newPlayerInGame.blockShot = 0;
	$scope.newPlayerInGame.personalFaul = 0;
	$scope.newPlayerInGame.totalPoints = 0;
	$scope.newPlayerInGame.totalRebounds = 0;
	
	$scope.teams = [];
	$scope.playersInGame = [];
	$scope.guestTeamId;
	$scope.hostTeamId;
	$scope.ballGameId;
//	$scope.ballGame.id;
	$scope.ballGame = {};
	
	
	var getGuestPlayers = function() {
		var config = { params: {}};
		if($scope.ballGame.id != ""){
			config.params.gameId = $scope.ballGame.id;
		}
		$http.get(baseUrlPlayersInGame + "/" + $scope.guestTeamId + "/byTeamId", config).then(
				function(res) {
					console.log(res.data);
					$scope.guestPlayers = res.data;
				}, function(res) {
					alert("wrong geting guestplayersInGame");
				})
	}
	var getHostPlayers = function() {
		var config = { params: {}};
		if($scope.ballGame.id != ""){
			config.params.gameId = $scope.ballGame.id;
		}
		$http.get(baseUrlPlayersInGame + "/" + $scope.hostTeamId + "/byTeamId", config).then(
				function(res) {
					console.log(res.data);
					$scope.hostPlayers = res.data;
				}, function(res) {
					alert("wrong geting guestplayersInGame");
				})
	}
	
	$scope.test = function(){
		getHostPlayers();
		getGuestPlayers();
	}
	
	
	$scope.addHost = function() {
		getHostPlayers();
	}

	$scope.addGuest = function() {
		getGuestPlayers();
	}
	
	
	var getTeams = function() {
		$http.get(baseUrlTeams).then(
				function(res) {
					$scope.teams = res.data;
				}, function(res) {
					alert("wrong getTeams");
				})
	}
	getTeams();
	
	$scope.addGame = function() {
		$scope.newBallGame.hostId = $scope.hostTeamId;
		$scope.newBallGame.guestId = $scope.guestTeamId;
		$http.post(baseUrlBallGame, $scope.newBallGame).then(
				function success(res) {
					$scope.ballGame = res.data;
					$scope.newBallGame = {};
					$scope.newBallGame.hostId;
					$scope.newBallGame.guest;
					$scope.newBallGame.hostPoints;
					$scope.newBallGame.guestPoints;
					$scope.newBallGame.hostTimeOut;
					$scope.newBallGame.guestTimeOut;
					$scope.newBallGame.date;
					console.log($scope.ballGame.id);
					console.log($scope.ballGame);
				}, function error(res) {
					alert("Unsuccessful $scope.addGame!");
				});
	};
	
	
	var result = function() {
		$http.get(baseUrlBallGame + "/result/" + $scope.ballGame.id).then(
				function success(res) {
					$scope.ballGame = res.data;
					console.log(res.data);
				}, function error(data) {
					alert("Unsuccessful $scope.result geting.");
				});

	};
	

	var getBallGame = function() {
		$http.get(baseUrlBallGame + "/" + $scope.ballGame.id).then(
				function success(res) {
					$scope.ballGame = res.data;
					console.log($scope.ballGame.id);
					console.log($scope.ballGameId);
				}, function error(data) {
					alert("Unsuccessful $scope.getBallGame geting.");
				});
		
	};
	
//	$scope.getGame = function(id){
//		$scope.ballGameId = id;
//		getBallGame();
//	}
//	
//	var addHostPlayers = function() {
//		var config = { params: {}};
//		if($scope.ballGame.id != ""){
//			config.params.gameId = $scope.ballGame.id;
//		}
//		$http.get(baseUrlPlayers + "/" + $scope.hostTeamId + "/byTeamId", config).then(
//				function(res) {
//				}, function(res) {
//					alert("wrong geting hostplayersInGame");
//				})
//	}
//	
//	var addGuestPlayers = function() {
//		var config = { params: {}};
//		if($scope.ballGame.id != ""){
//			config.params.gameId = $scope.ballGame.id;
//		}
//		$http.get(baseUrlPlayers + "/" + $scope.guestTeamId + "/byTeamId", config).then(
//				function(res) {
//				}, function(res) {
//					alert("wrong geting guestplayersInGame");
//				})
//	}
//	var getHostPlayers = function() {
//		var config = { params: {}};
//		if($scope.ballGame.id != ""){
//			config.params.gameId = $scope.ballGame.id;
//		}
//		$http.get(baseUrlPlayers + "/" + $scope.hostTeamId + "/byTeamId", config).then(
//				function(res) {
//					$scope.hostPlayers = res.data;
//				}, function(res) {
//					alert("wrong geting hostplayersInGame");
//				})
//	}
	
//	var getGuestPlayers = function() {
//		var config = { params: {}};
//		if($scope.ballGame.id != ""){
//			config.params.gameId = $scope.ballGame.id;
//		}
//		$http.get(baseUrlPlayers + "/" + $scope.guestTeamId + "/byTeamId", config).then(
//				function(res) {
//					$scope.guestPlayers = res.data;
//				}, function(res) {
//					alert("wrong geting guestplayersInGame");
//				})
//	}
	
//	var getPlayersInGame = function() {
//		$http.get(baseUrlPlayersInGame).then(
//				function(res) {
//					$scope.playersInGame = res.data;
//					console.log($scope.playersInGame);
//					console
//				}, function(res) {
//					alert("wrong getPlayersInGame");
//				})
//	}
//	getPlayersInGame();
//	var getPlayersInGame = function() {
//		$http.get(baseUrlPlayersInGame).then(
//				function(res) {
//					$scope.playersInGame = res.data;
//				}, function(res) {
//					alert("wrong getPlayersInGame");
//				})
//	}
//	getPlayersInGame();
	
	$scope.point1Shot = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/onePointShot").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
//					console.log($scope.teamAid);
//					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	$scope.point1Score = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/onePointScore").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful !");
				});

	}
	
	$scope.point3Shot = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/threePointShot").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful !");
				});

	}
	$scope.point3Score = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/threePointScore").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful !");
				});

	}
	
	$scope.point2Shot = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/twoPointShot").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	$scope.point2Score = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/twoPointScore").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful !");
				});

	}
	
	$scope.addAssists = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/assist").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful !");
				});

	}
	
	$scope.addOReb = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/off").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	$scope.addDReb = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/def").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful !");
				});

	}
	$scope.addFaul = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/faul").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
					console.log($scope.teamAid);
					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	$scope.addTO = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/to").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	$scope.addSteal = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/steal").then(
				function success(res) {
					result();
					getHostPlayers();
					getGuestPlayers();
//					console.log($scope.teamAid);
//					console.log($scope.teamBid);
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	$scope.addBlock = function(id) {
		$http.put(baseUrlPlayersInGame + "/" + id + "/block").then(
				function success(res) {
					getHostPlayers();
					getGuestPlayers();
					result();
				}, function error(res) {
					alert("Unsuccessful!");
				});

	}
	
	$(function () {
		$("body").tooltip({
			selector: '[data-toggle="tooltip"]',
			container: 'body'
		});
	})

    
	
	
//	$scope.edit = function() {
//		$http.put(baseUrlPlayers + $scope.oldPlayerId,
//				$scope.newPlayer).then(function success(data) {
//			alert("Successfull editing!");
//			$location.path("/");
//		}, function error(data) {
//			alert("Unsuccessful editing.");
//		});
//	}
});
